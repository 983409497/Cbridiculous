//
//  AppDelegate.h
//  ttt
//
//  Created by 梅维 on 2018/5/12.
//  Copyright © 2018年 uplooking. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

