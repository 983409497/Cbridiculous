//
//  AppDelegate.m
//  ttt
//
//  Created by 梅维 on 2018/5/12.
//  Copyright © 2018年 uplooking. All rights reserved.
//

#import "AppDelegate.h"
#import "SecWindowcontrller.h"

@interface AppDelegate ()

@property (weak) IBOutlet NSWindow *window;
@property (nonatomic,strong) SecWindowcontrller *secWc;
@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}
- (IBAction)createTable:(id)sender {
    if(!self.secWc)
    {
        self.secWc = [[SecWindowcontrller alloc ]initWithWindowNibName:@"SecWindowcontrller"];
    
    }
    [self.secWc showWindow:self];
}
- (IBAction)add:(id)sender {
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(autoAddData) userInfo:nil repeats:YES];
}

-(void)autoAddData{
    int num = rand()%100;
    int age = num;
    NSString *name = [NSString stringWithFormat:@"Tim%d",num];
    [self.secWc addData:age name:name];

}


@end
