//
//  DataModel.h
//  ttt
//
//  Created by 梅维 on 2018/5/12.
//  Copyright © 2018年 uplooking. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataModel : NSObject
@property (nonatomic,copy) NSString *name;
@property (nonatomic,copy) NSString *age;

@end
