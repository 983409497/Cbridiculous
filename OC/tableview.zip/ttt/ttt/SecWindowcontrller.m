//
//  SecWindowcontrller.m
//  ttt
//
//  Created by 梅维 on 2018/5/12.
//  Copyright © 2018年 uplooking. All rights reserved.
//

#import "SecWindowcontrller.h"
#import "DataModel.h"

@interface SecWindowcontrller ()<NSTableViewDataSource,NSTableViewDelegate>
@property (weak) IBOutlet NSTableView *tableview;
@property (strong,nonatomic) NSMutableArray *dataArr;
@end

@implementation SecWindowcontrller
- (NSMutableArray *)dataArr{
    if(!_dataArr)
    {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}
- (void)windowDidLoad {
    [super windowDidLoad];
    self.tableview.dataSource = self;
    self.tableview.delegate = self;
    
    // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
}

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView{
    return self.dataArr.count;
}
-(id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
    DataModel *md = self.dataArr[row];
    NSLog(@"1");
    if([tableColumn.identifier isEqualToString:@"name"]){
        NSLog(@"2");

        return md.name;
    }else if([tableColumn.identifier isEqualToString:@"age"]){
        NSLog(@"3");

        return md.age;
    }
    
    return nil;
}
- (void)addData:(int)age name:(NSString *)tname{
    DataModel *md = [[DataModel alloc]init];
    md.name = tname;
    md.age = [NSString stringWithFormat:@"%d",age];
    [self.dataArr addObject:md];
    [self.tableview reloadData];
}

@end
