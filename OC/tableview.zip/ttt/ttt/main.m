//
//  main.m
//  ttt
//
//  Created by 梅维 on 2018/5/12.
//  Copyright © 2018年 uplooking. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
